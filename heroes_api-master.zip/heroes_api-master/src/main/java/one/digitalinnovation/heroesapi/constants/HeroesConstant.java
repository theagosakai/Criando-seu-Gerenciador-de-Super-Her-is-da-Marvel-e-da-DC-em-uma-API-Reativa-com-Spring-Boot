package one.digitalinnovation.heroesapi.constants;

public class HeroesConstant {
	
	public static final String HEROES_ENDPOINT_LOCAL="/heroes";

}
